import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProviderService } from '@core/services/provider.service';
import { TranslateService } from '@ngx-translate/core';
import { CommonService } from '@shared/services/common.service';
import { ToastService, ToastType } from '@shared/services/toast.service';
import { TranslateConfigService } from '@shared/services/translate.config.service';
import { finalize } from 'rxjs/operators';
import { Menu } from '../../core/models/menu.model';
import { MenuService } from '../../core/services/menu.service';
import { Browser } from '@capacitor/browser';


@Component({
  selector: 'app-listing',
  templateUrl: './listing.page.html',
  styleUrls: ['./listing.page.scss'],
})
export class ListingPage implements OnInit {
  menus: Menu[] = [];

  isInvoicesPage = false;


  constructor(private route: Router, private activatedRoute: ActivatedRoute,private translate: TranslateService, private translateConfigService: TranslateConfigService, private menuService: MenuService, private router: Router, private providerService: ProviderService, private common: CommonService, private toastService: ToastService) {

  }


  switchLang() {
    if (this.translate.currentLang === 'ar') {
      this.translateConfigService.setLanguage('en');
    }
    else {
      this.translateConfigService.setLanguage('ar');
    }

  }

  ngOnInit() {
   
    this.menus = this.menuService.getMenus();

    if (this.router.url.includes('invoices')) {
      this.isInvoicesPage = true;
    }
  }



  openMenu(clickedItem: Menu) {
    clickedItem.active = true;
    this.menus.find(item => item.id != clickedItem.id).active = false;
    this.router.navigate([clickedItem.route], { replaceUrl: true });
  }


  deActiveAllMenusExcept(id: number) {
    this.menus.find(item => item.id == id).active = true;
    this.menus.find(item => item.id != id).active = false;
  }

  async linkedLogin() {
    this.common.showSpinner();
    this.providerService
      .initProvider('/provider/linkedIn/init').pipe(finalize(() => {
        this.common.hideSpinner();
      }))
      .subscribe(
        data => {
          // this.utilService.popupCenter({ url: data.authorizeUrl, w: 500, h: 500 });
          console.log(data);

          //  Browser.open({ url: data.authorizeUrl });

          this.open(data.authorizeUrl);
          // const openCapacitorSite = async () => {
          //   await Browser.open({ url: data.authorizeUrl });
          // };

          // const browser = this.iab.create(data.authorizeUrl);

          // // browser.executeScript(...);

          // // browser.insertCSS(...);
          // browser.on('loadstop').subscribe(event => {
          //   console.log('>>>>loadstop..');
          //   browser.insertCSS({ code: "body{color: red;" });
          // });

          // browser.close();

        },
        err => {
          console.error(err);
          this.toastService.showToast(err.message, ToastType.DANGER);
        }
      );
  }

  async open(authorizeUrl){
      await Browser.open({ url: authorizeUrl });
  
  }

  createProduct() {
    this.router.navigate(['/product-opt/new']);
  }


  isActive(url: string): boolean {
    return this.router.isActive(this.router.createUrlTree([url]), true);
  }

}
