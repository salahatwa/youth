import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inv-status-returns',
  templateUrl: './inv-status-returns.component.html',
  styleUrls: ['./inv-status-returns.component.scss'],
})
export class InvStatusReturnsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
