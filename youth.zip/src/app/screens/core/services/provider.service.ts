import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApiService } from '@shared/services/api.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { CustomHttpUrlEncodingCodec } from '../models';


@Injectable({
    providedIn: 'root'
})
export class ProviderService {


    constructor(private apiService: ApiService
    ) { }

    getUserProviderList(pageNo?: number, pageSize?: number, sortBy?: string): Observable<any> {
        let queryParameters = new HttpParams({ encoder: new CustomHttpUrlEncodingCodec() });
        if (pageNo !== undefined && pageNo !== null) {
            queryParameters = queryParameters.set('pageNo', <any>pageNo);
        }
        if (pageSize !== undefined && pageSize !== null) {
            queryParameters = queryParameters.set('pageSize', <any>pageSize);
        }
        if (sortBy !== undefined && sortBy !== null) {
            queryParameters = queryParameters.set('sortBy', <any>sortBy);
        }

        return this.apiService.get('/provider/accounts', queryParameters)
            .pipe(map(data => { return data; })
            );
    }


    public removeProviderById(id: string): Observable<any> {

        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling removeProviderByIdUsingDELETE.');
        }
        return this.apiService.delete(`/provider/delete/${encodeURIComponent(String(id))}`);
    }


    initProvider(path: string): Observable<any> {
        return this.apiService.get(path)
            .pipe(map(
                data => {
                    return data;
                }
            ));
    }

    verifyLinkedIn(path: string, oauth_token: string): Observable<any> {
        return this.apiService.post(path, {
            requestToken: oauth_token,
            oauthVerifier: ''
        })
            .pipe(map(
                data => {
                    //   this.setAuth(data);
                    return data;
                }
            ));
    }

}