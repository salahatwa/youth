export class Category {
    id?: number;
    name?: string;
    description?: string;

    index?:number;
    action?:string;
}
