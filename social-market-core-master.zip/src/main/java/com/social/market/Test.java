//package com.social.market;
//
//package autoChirp.tweeting;
//import java.util.Hashtable;
//import javax.inject.Inject;
//import javax.servlet.http.HttpSession;
//import org.springframework.social.connect.Connection;
//import org.springframework.social.connect.ConnectionData;
//import org.springframework.social.connect.ConnectionFactory;
//import org.springframework.social.connect.ConnectionRepository;
//import org.springframework.social.connect.web.ConnectInterceptor;
//import org.springframework.social.oauth1.AuthorizedRequestToken;
//import org.springframework.social.oauth1.OAuth1Operations;
//import org.springframework.social.oauth1.OAuthToken;
//import org.springframework.social.twitter.api.Twitter;
//import org.springframework.social.twitter.api.TwitterProfile;
//import org.springframework.social.twitter.api.UserOperations;
//import org.springframework.social.twitter.connect.TwitterConnectionFactory;
//import org.springframework.stereotype.Component;
//import org.springframework.util.MultiValueMap;
//import org.springframework.web.context.request.WebRequest;
//import autoChirp.DBConnector;
///**
// * A Spring Social ConnectInterceptor responsible for Twitter authentication.
// * This class implements a interceptor for Twitter-connect workflows, provided
// * by the Spring Social Twitter module. While the preConnect method has an empty
// * body, the postConnect method makes the magic happen: As soon as a successful
// * connection is established to Twitter, the associated user is searched for in
// * the database - if none is found, a new user (and the Twitter API secrets) is
// * created. Then all detail relevant to the application is stored in the user
// * session. At last the connection to Twitter is closed, as it isn't needed.
// *
// * @author Philip Schildkamp
// */
//@Component
//public class TwitterAccount implements ConnectInterceptor<Twitter> {
//	private ConnectionRepository connectionRepository;
//	private HttpSession session;
//	/**
//	 * Constructor method, used to autowire and inject necessary objects.
//	 *
//	 * @param connectionRepository Autowired ConnectionRepository object
//	 * @param session              Autowired HttpSession object
//	 */
//	@Inject
//	public TwitterAccount(ConnectionRepository connectionRepository, HttpSession session) {
//		this.connectionRepository = connectionRepository;
//		this.session = session;
//	}
//	/*
//	 * (non-Javadoc)
//	 *
//	 * @see
//	 * org.springframework.social.connect.web.ConnectInterceptor#preConnect(org.
//	 * springframework.social.connect.ConnectionFactory,
//	 * org.springframework.util.MultiValueMap,
//	 * org.springframework.web.context.request.WebRequest)
//	 */
//	public void preConnect(ConnectionFactory<Twitter> connectionFactory, MultiValueMap<String, String> parameters,
//			WebRequest request) {
//	}
//	public static void main(String[] args) {
////		TwitterConnectionFactory connectionFactory = new TwitterConnectionFactory("sYbfuubUJzhg1gCHFxh2cNUQ4",
////				"ITw4dWmjqOZUTeElDDtZIRkOE3Xao6cfMgmcLJsTAwlO2S4nrY");
////		OAuth1Operations oauthOperations = connectionFactory.getOAuthOperations();
////		OAuthToken requestToken = oauthOperations.fetchRequestToken("http://127.0.0.1:4200/linkedInLogin", null);
////		String authorizeUrl = oauthOperations.buildAuthorizeUrl(requestToken.getValue(), OAuth1Parameters.NONE);
////		System.out.println(authorizeUrl);
//		getAccessToken("UXVpQAAAAAABGwyNAAABc_Zbm_k", "Pvn0zQKxq1nASvzyGYwwfvUsG4SxJ6b9");
//	}
//	public static void getAccessToken(String requestToken, String oauthVerifier) {
//		TwitterConnectionFactory connectionFactory = new TwitterConnectionFactory("sYbfuubUJzhg1gCHFxh2cNUQ4",
//				"ITw4dWmjqOZUTeElDDtZIRkOE3Xao6cfMgmcLJsTAwlO2S4nrY");
////		OAuth1Operations oauthOperations = connectionFactory.getOAuthOperations();
//		
////		ZpUZI2DQkxigijrTZYH0rrBBJnsiw3KsnoIkh4iLosKS2
////		1286295565828005888-PKpzYfmqSXSwJDyC2BBLnpNeOlaCXj
//		
////		OAuthToken accessToken = oauthOperations.exchangeForAccessToken(
////				new AuthorizedRequestToken(new OAuthToken(requestToken, ""), oauthVerifier), null);
////		
////		System.out.println(accessToken.getSecret());
////		System.out.println(accessToken.getValue());
//		
//		
//		
//		OAuthToken accessToken=new OAuthToken("1286295565828005888-PKpzYfmqSXSwJDyC2BBLnpNeOlaCXj", "ZpUZI2DQkxigijrTZYH0rrBBJnsiw3KsnoIkh4iLosKS2");
//		Connection<Twitter> twitterConnection = connectionFactory.createConnection(accessToken);
//		Twitter twitter = twitterConnection.getApi();
//		UserOperations userOperations = twitter.userOperations();
//		TwitterProfile twitterProfile = userOperations.getUserProfile();
//		long twitterID = userOperations.getProfileId();
//		
//		Hashtable<String, String> account = new Hashtable<String, String>();
////		account.put("userID", Integer.toString(userID));
//		account.put("twitterID", Long.toString(twitterID));
//		account.put("name", twitterProfile.getName());
//		account.put("geoEnabled", String.valueOf(twitterProfile.isGeoEnabled()));
//		account.put("handle", twitterProfile.getScreenName());
//		account.put("description", twitterProfile.getDescription());
//		account.put("url", twitterProfile.getProfileUrl());
//		account.put("image", twitterProfile.getProfileImageUrl());
//		account.put("protected", String.valueOf(twitterProfile.isProtected()));
//		
//		System.out.println(account);
//		
//	}
//	/*
//	 * (non-Javadoc)
//	 *
//	 * @see
//	 * org.springframework.social.connect.web.ConnectInterceptor#postConnect(org
//	 * .springframework.social.connect.Connection,
//	 * org.springframework.web.context.request.WebRequest)
//	 */
//	public void postConnect(Connection<Twitter> twitterConnection, WebRequest request) {
//		Twitter twitter = twitterConnection.getApi();
//		UserOperations userOperations = twitter.userOperations();
//		TwitterProfile twitterProfile = userOperations.getUserProfile();
//		long twitterID = userOperations.getProfileId();
//		int userID = DBConnector.checkForUser(twitterID);
//		if (userID == -1) {
//			ConnectionData twitterConnectionData = twitterConnection.createData();
//			String token = twitterConnectionData.getAccessToken();
//			String secret = twitterConnectionData.getSecret();
//			userID = DBConnector.insertNewUser(twitterID, token, secret);
//		}
//		Hashtable<String, String> account = new Hashtable<String, String>();
//		account.put("userID", Integer.toString(userID));
//		account.put("twitterID", Long.toString(twitterID));
//		account.put("name", twitterProfile.getName());
//		account.put("geoEnabled", String.valueOf(twitterProfile.isGeoEnabled()));
//		account.put("handle", twitterProfile.getScreenName());
//		account.put("description", twitterProfile.getDescription());
//		account.put("url", twitterProfile.getProfileUrl());
//		account.put("image", twitterProfile.getProfileImageUrl());
//		account.put("protected", String.valueOf(twitterProfile.isProtected()));
//		session.setAttribute("account", account);
//		connectionRepository.removeConnection(twitterConnection.getKey());
//	}
//}