package com.social.market.service;

import java.util.function.Function;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.social.market.domain.Provider;
import com.social.market.domain.dto.PageProviderDto;
import com.social.market.domain.dto.ProviderDto;
import com.social.market.repository.ProviderRepository;

@Service
public class ProviderService {

	@Autowired
	private ProviderRepository providerRepo;

	public PageProviderDto getAllAccountsForUser(String userId,Integer pageNo, Integer pageSize, String sortBy) {
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));

		Page<Provider> pagedResult = providerRepo.findByUser_id(userId,paging);

		if (pagedResult.hasContent()) {

			Page<ProviderDto> dtoPage = pagedResult.map(new Function<Provider, ProviderDto>() {
				@Override
				public ProviderDto apply(Provider entity) {
					ProviderDto dto = new ProviderDto();
					BeanUtils.copyProperties(entity, dto);

					return dto;
				}
			});

			return new PageProviderDto(dtoPage.getContent(), pagedResult.getTotalElements());
		} else {
			return new  PageProviderDto();
		}
	}
	
	
	public void removeAccountById(String id) {
		this.providerRepo.deleteById(id);
	}

}
