package com.social.market.service;

import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.social.market.domain.Provider;
import com.social.market.domain.Task;
import com.social.market.domain.dto.schedule.PageTaskDto;
import com.social.market.domain.dto.schedule.TaskDto;
import com.social.market.exceptions.ResourceNotFoundException;
import com.social.market.repository.ProviderRepository;
import com.social.market.repository.TaskRepository;
import com.social.market.service.schedule.ScheduleService;

@Service
public class TaskService {

	@Autowired
	private ScheduleService scheduleService;

	@Autowired
	private TaskRepository taskRepo;

	@Autowired
	private ProviderRepository providerRepository;

	public TaskDto getTaskForUser(String userId, long taskId) {

		Task task = taskRepo.findByIdAndCreatedBy(taskId, userId).orElseThrow(() -> new ResourceNotFoundException(""));

		TaskDto dto = new TaskDto();
		BeanUtils.copyProperties(task, dto);

		List<String> providerIds = task.getProviders().stream().map(Provider::getId).collect(Collectors.toList());

		dto.setProvidersId(providerIds);

		return dto;
	}

	public Task getEntityTaskForUser(String userId, long taskId) {
		Task task = taskRepo.findByIdAndCreatedBy(taskId, userId).orElseThrow(() -> new ResourceNotFoundException(""));

		return task;
	}

	public PageTaskDto getAllTasksForUser(String userId, Integer pageNo, Integer pageSize, String sortBy) {
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(Sort.Direction.DESC, sortBy));

		Page<Task> pagedResult = taskRepo.findByCreatedBy(userId, paging);

		System.out.println(pagedResult.getTotalElements());

		if (pagedResult.hasContent()) {

			Page<TaskDto> dtoPage = pagedResult.map(new Function<Task, TaskDto>() {
				@Override
				public TaskDto apply(Task entity) {
					TaskDto dto = new TaskDto();

					BeanUtils.copyProperties(entity, dto);

					return dto;
				}
			});

			return new PageTaskDto(dtoPage.getContent(), pagedResult.getTotalElements());
		} else {
			return new PageTaskDto();
		}
	}

	public TaskDto save(String userId, TaskDto taskDto) {

		Task task = new Task();

		if (Objects.nonNull(taskDto) && Objects.nonNull(taskDto.getId()) && taskDto.getId() != 0) {
			task = taskRepo.findById(taskDto.getId()).orElseThrow(() -> new ResourceNotFoundException("NotFound"));
		}
		BeanUtils.copyProperties(taskDto, task);

		task = taskRepo.save(task);

		taskDto.setId(task.getId());


		if (taskDto.isEnabled()) {
			List<Provider> providers = providerRepository.findAllProvidersByTaskId(task.getId());
			task=scheduleService.schedulePost(providers, task);
			BeanUtils.copyProperties(taskDto, task);
		}

		return taskDto;
	}

	public void delete(long id) {
		taskRepo.deleteById(id);
	}

	public void addProviderToTask(String userId, long taskId, String providerId) {

		Task task = taskRepo.findByIdAndCreatedBy(taskId, userId).orElseThrow(() -> new ResourceNotFoundException(""));

		Provider provider = providerRepository.findById(providerId)
				.orElseThrow(() -> new ResourceNotFoundException(""));

		task.addProvider(provider);

		taskRepo.save(task);

		System.out.println(task);

//		return dto;
	}

	public void removeProviderToTask(String userId, long taskId, String providerId) {

		Task task = taskRepo.findByIdAndCreatedBy(taskId, userId).orElseThrow(() -> new ResourceNotFoundException(""));

		Provider provider = providerRepository.findById(providerId)
				.orElseThrow(() -> new ResourceNotFoundException(""));

		task.removeProvider(provider);

		taskRepo.save(task);

		System.out.println(task);

//		return dto;
	}

}
