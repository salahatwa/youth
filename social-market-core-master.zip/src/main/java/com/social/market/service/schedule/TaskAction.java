package com.social.market.service.schedule;

import java.util.List;

import com.social.market.domain.Provider;
import com.social.market.domain.Task;

public interface TaskAction {
	public long execute(List<Provider> providers,Task task);
}
