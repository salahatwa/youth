package com.social.market.domain.dto;

import lombok.Data;

@Data
public class LinkedInRqTokenRs {
	private String access_token;
	private String expires_in;
}
