package com.social.market.domain;

public enum ProviderType {
	SELF, TWITTER, LINKEDIN;

	ProviderType() {
	}
}
