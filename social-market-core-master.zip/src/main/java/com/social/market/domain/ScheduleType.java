package com.social.market.domain;

public enum ScheduleType {
	POST,DATETIME,DATERANGE,MULTIPLE;

}
