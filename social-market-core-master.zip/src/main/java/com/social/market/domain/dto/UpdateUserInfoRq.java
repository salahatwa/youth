package com.social.market.domain.dto;

import javax.validation.constraints.Email;

import lombok.Data;

@Data
public class UpdateUserInfoRq {
	@Email(message = "should be an email")
	private String email = "";
	private String username = "";
	private String bio = "";
}
