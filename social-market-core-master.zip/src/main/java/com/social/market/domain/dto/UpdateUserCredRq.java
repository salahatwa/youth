package com.social.market.domain.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class UpdateUserCredRq {

	@NotBlank(message = "pass can't be empty")
	private String oldPassword = "";
	@NotBlank(message = "new pass can't be empty")
	private String newPassword = "";

}
