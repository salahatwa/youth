package com.social.market.domain.dto;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.social.market.domain.ProviderType;
import com.social.market.domain.audit.DateAudit;

import lombok.Data;

@Data
public class ProviderDto extends DateAudit {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String name;
	private boolean isGeoEnabled;
	private String handle;
	private String email;
	private String description;
	private String expireAt;

	private String url;
	private String image;
	private boolean secure;

	@Enumerated(EnumType.ORDINAL)
	private ProviderType providerType;

}
