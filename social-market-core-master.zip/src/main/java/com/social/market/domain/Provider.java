package com.social.market.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.social.market.domain.audit.DateAudit;

import lombok.Data;

@Data
@Entity
public class Provider extends DateAudit {

	@Id
	private String id;
	private String name;
	private boolean isGeoEnabled;
	private String handle;
	private String email;
	private String description;
	private String expireAt;

	private String url;
	private String image;
	private boolean secure;

	@Column(columnDefinition = "text")
	private String token;
	private String secret;

	@Enumerated(EnumType.ORDINAL)
	private ProviderType providerType;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id")
//	@JsonIgnoreProperties("user")
	private User user;

	@ManyToMany(mappedBy = "providers", fetch = FetchType.LAZY)
	@JsonIgnoreProperties("providers")
	private List<Task> tasks = new ArrayList<>();
}
