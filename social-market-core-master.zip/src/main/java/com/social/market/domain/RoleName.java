package com.social.market.domain;


public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
