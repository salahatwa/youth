package com.social.market.domain.dto;

import lombok.Data;

@Data
public class SocialRq {
	private String requestToken;
	private String oauthVerifier;
}
