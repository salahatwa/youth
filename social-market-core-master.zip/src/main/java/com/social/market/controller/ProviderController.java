package com.social.market.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.social.connect.Connection;
import org.springframework.social.oauth1.AuthorizedRequestToken;
import org.springframework.social.oauth1.OAuth1Operations;
import org.springframework.social.oauth1.OAuth1Parameters;
import org.springframework.social.oauth1.OAuthToken;
import org.springframework.social.twitter.api.Twitter;
import org.springframework.social.twitter.api.TwitterProfile;
import org.springframework.social.twitter.api.UserOperations;
import org.springframework.social.twitter.connect.TwitterConnectionFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.social.market.config.SocialConfig;
import com.social.market.config.secuirty.CurrentUser;
import com.social.market.config.secuirty.JwtTokenProvider;
import com.social.market.config.secuirty.UserPrincipal;
import com.social.market.domain.Provider;
import com.social.market.domain.ProviderType;
import com.social.market.domain.User;
import com.social.market.domain.dto.LinkedInRqToken;
import com.social.market.domain.dto.LinkedInRqTokenRs;
import com.social.market.domain.dto.PageProviderDto;
import com.social.market.domain.dto.SocialRq;
import com.social.market.domain.dto.SocialRs;
import com.social.market.domain.dto.UserData;
import com.social.market.exceptions.ResourceNotFoundException;
import com.social.market.repository.ProviderRepository;
import com.social.market.repository.RoleRepository;
import com.social.market.repository.UserRepository;
import com.social.market.service.ProviderService;

@RestController
@RequestMapping("/provider")
public class ProviderController {

	@Autowired
	private ProviderService providerService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	JwtTokenProvider tokenProvider;

	@Autowired
	SocialConfig socialConfig;

	@Autowired
	private ProviderRepository profileRepository;

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> removeProviderById(@CurrentUser UserPrincipal currentUser, @PathVariable String id) {
		
		this.providerService.removeAccountById(id);

		return ResponseEntity.ok(true);
	}

	@GetMapping("/accounts")
	public ResponseEntity<PageProviderDto> getAllUserSocialAccounts(@CurrentUser UserPrincipal currentUser,
			@RequestParam(defaultValue = "0") Integer pageNo, @RequestParam(defaultValue = "10") Integer pageSize,
			@RequestParam(defaultValue = "id") String sortBy) {

		return ResponseEntity.ok(providerService.getAllAccountsForUser(currentUser.getId(), pageNo, pageSize, sortBy));
	}

	@GetMapping("/twitter/init")
	public ResponseEntity<SocialRs> twitterIntialize() {

		TwitterConnectionFactory connectionFactory = new TwitterConnectionFactory(socialConfig.getTwitterKey(),
				socialConfig.getTwitterSecret());

		OAuth1Operations oauthOperations = connectionFactory.getOAuthOperations();
		OAuthToken requestToken = oauthOperations.fetchRequestToken(socialConfig.getTwitterCallBack1(), null);
		String authorizeUrl = oauthOperations.buildAuthorizeUrl(requestToken.getValue(), OAuth1Parameters.NONE);

		return ResponseEntity.ok(new SocialRs(authorizeUrl));
	}

	@GetMapping("/linkedIn/init")
	public ResponseEntity<SocialRs> linkedInIntialize() {

		String url = "https://www.linkedin.com/uas/oauth2/authorization?response_type=code&client_id="
				+ socialConfig.getLinkedInKey() + "&scope=r_emailaddress,r_liteprofile,w_member_social&redirect_uri="
				+ socialConfig.getLinkedInCallBack1();

		return ResponseEntity.ok(new SocialRs(url));
	}

	@PostMapping("/linkedIn/request-token")
	public ResponseEntity<UserData> linkedInRqToken(@CurrentUser UserPrincipal currenUser,
			@RequestBody SocialRq socialRq) throws JSONException {

		System.out.println(">>>>>>>>>>>>>>>" + currenUser.getName() + ":ID:" + currenUser.getId());

		LinkedInRqToken rq = new LinkedInRqToken();
		rq.setClient_id(socialConfig.getLinkedInKey());
		rq.setClient_secret(socialConfig.getLinkedInSecret());
		rq.setCode(socialRq.getRequestToken());
		rq.setGrant_type("authorization_code");
		rq.setRedirect_uri(socialConfig.getLinkedInCallBack1());

		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add("grant_type", "authorization_code");
		map.add("code", socialRq.getRequestToken());
		map.add("client_id", socialConfig.getLinkedInKey());
		map.add("client_secret", socialConfig.getLinkedInSecret());
		map.add("redirect_uri", socialConfig.getLinkedInCallBack1());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(map, headers);

		RestTemplate restTemplate = new RestTemplateBuilder().build();
		LinkedInRqTokenRs rs = restTemplate.exchange("https://www.linkedin.com/oauth/v2/accessToken", HttpMethod.POST,
				requestEntity, LinkedInRqTokenRs.class).getBody();

		System.out.println(rs.getAccess_token());
		headers.add("Authorization", "Bearer " + rs.getAccess_token());

		HttpEntity entity = new HttpEntity<>(headers);
		String p = restTemplate.exchange(
				"https://api.linkedin.com/v2/me?projection=(id,firstName,lastName,emailAddress,profilePicture(displayImage~:playableStreams))",
				HttpMethod.GET, entity, String.class).getBody();

		System.out.println(p);
		JSONObject obj = new JSONObject(p);
		System.out.println(obj.get("id"));
		System.out.println(obj.getJSONObject("firstName").getJSONObject("localized").get("en_US"));
		System.out.println(obj.getJSONObject("lastName").getJSONObject("localized").get("en_US"));
		System.out.println(obj.getJSONObject("profilePicture").getJSONObject("displayImage~").getJSONArray("elements")
				.getJSONObject(0).getJSONArray("identifiers").getJSONObject(0).get("identifier"));
		String userId = (String) obj.get("id");

		String name = obj.getJSONObject("firstName").getJSONObject("localized").get("en_US") + " "
				+ obj.getJSONObject("lastName").getJSONObject("localized").get("en_US");

		String imgUrl = (String) obj.getJSONObject("profilePicture").getJSONObject("displayImage~")
				.getJSONArray("elements").getJSONObject(0).getJSONArray("identifiers").getJSONObject(0)
				.get("identifier");
		Optional<Provider> profilet = profileRepository.findById(userId);

		User user = null;

		if (profilet.isPresent())
			user = profilet.get().getUser();
		else {
			user = userRepository.findById(currenUser.getId())
					.orElseThrow(() -> new ResourceNotFoundException("ERROR_usernotfound"));

			Provider profile = new Provider();
//			profile.setDescription(name);
			profile.setId(userId);
			profile.setName(name);
//			profile.setGeoEnabled(twitterProfile.isGeoEnabled());
//			profile.setUrl(twitterProfile.getProfileUrl());
			profile.setImage(imgUrl);
//			profile.setSecure(twitterProfile.isProtected());
			profile.setProviderType(ProviderType.LINKEDIN);
			profile.setToken(rs.getAccess_token());

//			Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
//					.orElseThrow(() -> new SocialException(Constant.INTERNAL_ERROR));
//
//			user.setRoles(Collections.singleton(userRole));
			user.setImage(imgUrl);
			user.setCreator(ProviderType.LINKEDIN);
			user.addProfile(profile);
		}

		User result = userRepository.save(user);

		return ResponseEntity.ok(new UserData(tokenProvider.toToken(result), UserPrincipal.create(result)));
	}

	@PostMapping("/twitter/request-token")
	public ResponseEntity<UserData> twitterRqToken(@CurrentUser UserPrincipal currenUser,
			@Valid @RequestBody SocialRq socialRq) {

		TwitterConnectionFactory connectionFactory = new TwitterConnectionFactory(socialConfig.getTwitterKey(),
				socialConfig.getTwitterSecret());
		OAuth1Operations oauthOperations = connectionFactory.getOAuthOperations();

//		OAuthToken rqAccessToken = oauthOperations.exchangeForAccessToken(
//				new AuthorizedRequestToken(new OAuthToken(socialRq.getRequestToken(), socialRq.getOauthVerifier()),null ),
//				null);

		// upon receiving the callback from the provider:
		OAuthToken accessToken = oauthOperations.exchangeForAccessToken(new AuthorizedRequestToken(
				new OAuthToken(socialRq.getRequestToken(), null), socialRq.getOauthVerifier()), null);

		System.out.println(accessToken.getSecret());
		System.out.println(accessToken.getValue());

//		OAuthToken accessToken = new OAuthToken(rqAccessToken.getValue(), rqAccessToken.getSecret());
		Connection<Twitter> twitterConnection = connectionFactory.createConnection(accessToken);
		Twitter twitter = twitterConnection.getApi();
//		twitterConnection.updateStatus("hello all my friends");

		UserOperations userOperations = twitter.userOperations();
		TwitterProfile twitterProfile = userOperations.getUserProfile();

		long twitterID = userOperations.getProfileId();

//		twitter.timelineOperations().updateStatus("hello all");

		Optional<Provider> profilet = profileRepository.findById(String.valueOf(twitterID));

		User user = null;

		if (profilet.isPresent()) {
			Provider prof = profilet.get();
			user = prof.getUser();
			prof.setToken(accessToken.getValue());
			prof.setSecret(accessToken.getSecret());

			System.out.println("Token updated");
			profileRepository.save(prof);
		} else {
			user = userRepository.findById(currenUser.getId())
					.orElseThrow(() -> new ResourceNotFoundException("ERROR_usernotfound"));

			Provider profile = new Provider();
			profile.setDescription(twitterProfile.getDescription());
			profile.setId(Long.toString(twitterID));
			profile.setName(twitterProfile.getName());
			profile.setGeoEnabled(twitterProfile.isGeoEnabled());
			profile.setUrl(twitterProfile.getProfileUrl());
			profile.setImage(twitterProfile.getProfileImageUrl());
			profile.setSecure(twitterProfile.isProtected());
			profile.setProviderType(ProviderType.TWITTER);
			profile.setToken(accessToken.getValue());
			profile.setSecret(accessToken.getSecret());

//			Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
//					.orElseThrow(() -> new SocialException(Constant.INTERNAL_ERROR));

//			user.setRoles(Collections.singleton(userRole));
//			user.setBio(twitterProfile.getDescription());
//			user.setImage(twitterProfile.getProfileImageUrl());
//			user.setCreator(ProviderType.TWITTER);
			user.addProfile(profile);
		}

		User result = userRepository.save(user);

		return ResponseEntity.ok(new UserData(tokenProvider.toToken(result), UserPrincipal.create(result)));
	}

}
