package com.social.market.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.social.market.config.secuirty.CurrentUser;
import com.social.market.config.secuirty.JwtTokenProvider;
import com.social.market.config.secuirty.UserPrincipal;
import com.social.market.domain.dto.UpdateUserCredRq;
import com.social.market.domain.dto.UpdateUserInfoRq;
import com.social.market.domain.dto.UserData;
import com.social.market.exceptions.ResourceNotFoundException;
import com.social.market.repository.UserRepository;

@RestController
@RequestMapping("/user")
@Validated
public class UserController {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	JwtTokenProvider tokenProvider;

//	@Autowired
//	DriveStorageService storageService;

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	

	

	@PutMapping("/update/cred")
	@PreAuthorize("hasRole('USER')")
	public ResponseEntity<?> updateUserSecrets(@CurrentUser UserPrincipal currentUser,
			@Valid @RequestBody UpdateUserCredRq updateUserParam, BindingResult bindingResult) {

//        checkUniquenessOfUsernameAndEmail(currentUser, updateUserParam, bindingResult);

		return userRepository.findById(currentUser.getId()).map(oldUser -> {

			if (updateUserParam.getOldPassword() != null && updateUserParam.getOldPassword() != "") {
				System.out.println(oldUser.getPassword()+"::"+updateUserParam.getOldPassword());
				System.out.println(passwordEncoder.encode(updateUserParam.getOldPassword()));
				if (passwordEncoder.matches(updateUserParam.getOldPassword(),oldUser.getPassword()))
				{
					oldUser.setPassword(passwordEncoder.encode(updateUserParam.getNewPassword()));
					oldUser = userRepository.save(oldUser);
				}else
				{
					throw  new ResourceNotFoundException("User", "CREDENTIALS", currentUser.getName());
				}
			}

			
			UserData updatedUser = new UserData(tokenProvider.toToken(oldUser), UserPrincipal.create(oldUser));
			return ResponseEntity.ok(updatedUser);

		}).orElseThrow(() -> new ResourceNotFoundException("User", "username", currentUser.getName()));
	}

	@PutMapping("/update/info")
	@PreAuthorize("hasRole('USER')")
	public ResponseEntity<?> updateUserInfo(@CurrentUser UserPrincipal currentUser,
			@Valid @RequestBody UpdateUserInfoRq updaInfoParam, BindingResult bindingResult) {

		return userRepository.findById(currentUser.getId()).map(oldUser -> {

			oldUser.setBio(updaInfoParam.getBio());
			oldUser.setUsername(updaInfoParam.getUsername());
			oldUser = userRepository.save(oldUser);

			
			UserData updatedUser = new UserData(tokenProvider.toToken(oldUser), UserPrincipal.create(oldUser));
			return ResponseEntity.ok(updatedUser);

		}).orElseThrow(() -> new ResourceNotFoundException("User", "username", currentUser.getName()));
	}

	
	@PostMapping("/update/profilpic")
	public ResponseEntity<?> updateProfilePic(@RequestHeader(value = "Authorization") String authorization,@CurrentUser UserPrincipal currentUser,
			@RequestParam(name = "file") MultipartFile file) {
				return null;

//		return userRepository.findById(currentUser.getId()).map(oldUser -> {

//			try {
//				UploadFileResponse fileRes = storageService.uploadFile(file);
//				String picURL = fileRes.getData().getBaseurl() + fileRes.getData().getFiles().get(0);
//
//				oldUser.setImage(picURL);
//
//				oldUser = userRepository.save(oldUser);
//				UserData updatedUser = new UserData(authorization, UserPrincipal.create(oldUser));
//				return ResponseEntity.ok(updatedUser);
				
//			} catch (Exception ex) {
//				ex.printStackTrace();
//			}
//			return null;

//		}).orElseThrow(() -> new ResourceNotFoundException("User", "username", currentUser.getName()));
	}

	

}
