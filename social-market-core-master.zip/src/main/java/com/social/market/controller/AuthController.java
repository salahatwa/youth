package com.social.market.controller;

import java.net.URI;
import java.util.Collections;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.social.connect.Connection;
import org.springframework.social.oauth1.AuthorizedRequestToken;
import org.springframework.social.oauth1.OAuth1Operations;
import org.springframework.social.oauth1.OAuth1Parameters;
import org.springframework.social.oauth1.OAuthToken;
import org.springframework.social.twitter.api.Twitter;
import org.springframework.social.twitter.api.TwitterProfile;
import org.springframework.social.twitter.api.UserOperations;
import org.springframework.social.twitter.connect.TwitterConnectionFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.social.market.config.SocialConfig;
import com.social.market.config.secuirty.CurrentUser;
import com.social.market.config.secuirty.JwtTokenProvider;
import com.social.market.config.secuirty.UserPrincipal;
import com.social.market.domain.Provider;
import com.social.market.domain.ProviderType;
import com.social.market.domain.Role;
import com.social.market.domain.RoleName;
import com.social.market.domain.User;
import com.social.market.domain.dto.LinkedInRqToken;
import com.social.market.domain.dto.LinkedInRqTokenRs;
import com.social.market.domain.dto.LoginRq;
import com.social.market.domain.dto.SignUpRq;
import com.social.market.domain.dto.SocialRq;
import com.social.market.domain.dto.SocialRs;
import com.social.market.domain.dto.UserData;
import com.social.market.exceptions.InvalidUsernamePasswordException;
import com.social.market.exceptions.ResourceAlreadyExistException;
import com.social.market.exceptions.SocialException;
import com.social.market.repository.ProviderRepository;
import com.social.market.repository.RoleRepository;
import com.social.market.repository.UserRepository;
import com.social.market.utils.Constant;

@RestController
@RequestMapping("/auth")
public class AuthController {

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UserRepository userRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	JwtTokenProvider tokenProvider;

	@Autowired
	SocialConfig socialConfig;

	@Autowired
	private ProviderRepository profileRepository;

//	@Autowired
//	private RestTemplate restTemplate;

	private String getJwtFromRequest(String bearerToken) {
		if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
			return bearerToken.substring(7, bearerToken.length());
		}
		return null;
	}

	@GetMapping("/me")
	@PreAuthorize("hasRole('USER')")
	public UserData getCurrentUser(@CurrentUser UserPrincipal currentUser,
			@RequestHeader(value = "Authorization") String authorization) {
		UserData userSummary = new UserData(getJwtFromRequest(authorization), currentUser);
		System.out.println(">>>>>>>>>::" + userSummary.getProfile().getId());
//        userSummary.setProfile(currentUser);
		return userSummary;
	}

	@PostMapping("/login")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRq loginRequest) {
		String jwt = null;
		UserPrincipal userPrincipal = null;
		try {
			Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
					loginRequest.getUsername(), loginRequest.getPassword()));

			SecurityContextHolder.getContext().setAuthentication(authentication);

			userPrincipal = (UserPrincipal) authentication.getPrincipal();
			jwt = tokenProvider.generateToken(authentication);
		} catch (Exception ex) {
			throw new InvalidUsernamePasswordException("user " + ex.getMessage(), "Email or Password",
					loginRequest.getUsername());
		}
		return ResponseEntity.ok(new UserData(jwt, userPrincipal));
	}

	@GetMapping("/twitter/init")
	public ResponseEntity<SocialRs> twitterIntialize() {

		TwitterConnectionFactory connectionFactory = new TwitterConnectionFactory(socialConfig.getTwitterKey(),
				socialConfig.getTwitterSecret());

		OAuth1Operations oauthOperations = connectionFactory.getOAuthOperations();
		OAuthToken requestToken = oauthOperations.fetchRequestToken(socialConfig.getTwitterCallBack(), null);
		String authorizeUrl = oauthOperations.buildAuthorizeUrl(requestToken.getValue(), OAuth1Parameters.NONE);

		return ResponseEntity.ok(new SocialRs(authorizeUrl));
	}

	@GetMapping("/linkedIn/init")
	public ResponseEntity<SocialRs> linkedInIntialize() {

		String url = "https://www.linkedin.com/uas/oauth2/authorization?response_type=code&client_id="
				+ socialConfig.getLinkedInKey() + "&scope=r_emailaddress,r_liteprofile,w_member_social&redirect_uri="
				+ socialConfig.getLinkedInCallBack();

		return ResponseEntity.ok(new SocialRs(url));
	}

	@PostMapping("/linkedIn/request-token")
	public ResponseEntity<UserData> linkedInRqToken(@RequestBody SocialRq socialRq) throws JSONException {

		System.out.println(">>>>>>>>>>>>>>>");

		LinkedInRqToken rq = new LinkedInRqToken();
		rq.setClient_id(socialConfig.getLinkedInKey());
		rq.setClient_secret(socialConfig.getLinkedInSecret());
		rq.setCode(socialRq.getRequestToken());
		rq.setGrant_type("authorization_code");
		rq.setRedirect_uri(socialConfig.getLinkedInCallBack());

		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add("grant_type", "authorization_code");
		map.add("code", socialRq.getRequestToken());
		map.add("client_id", socialConfig.getLinkedInKey());
		map.add("client_secret", socialConfig.getLinkedInSecret());
		map.add("redirect_uri", socialConfig.getLinkedInCallBack());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(map, headers);

		RestTemplate restTemplate = new RestTemplateBuilder().build();
		LinkedInRqTokenRs rs = restTemplate.exchange("https://www.linkedin.com/oauth/v2/accessToken", HttpMethod.POST,
				requestEntity, LinkedInRqTokenRs.class).getBody();

		System.out.println(">>>>>>>>>Access Token:"+rs.getAccess_token());
		System.out.println(">>>>>>>>>Expire IN:"+rs.getExpires_in());
		headers.add("Authorization", "Bearer " + rs.getAccess_token());

		HttpEntity entity = new HttpEntity<>(headers);
		String p = restTemplate.exchange(
				"https://api.linkedin.com/v2/me?projection=(id,firstName,lastName,emailAddress,profilePicture(displayImage~:playableStreams))",
				HttpMethod.GET, entity, String.class).getBody();

		System.out.println(p);
		JSONObject obj = new JSONObject(p);
		System.out.println(obj.get("id"));
		System.out.println(obj.getJSONObject("firstName").getJSONObject("localized").get("en_US"));
		System.out.println(obj.getJSONObject("lastName").getJSONObject("localized").get("en_US"));
		System.out.println(obj.getJSONObject("profilePicture").getJSONObject("displayImage~").getJSONArray("elements")
				.getJSONObject(0).getJSONArray("identifiers").getJSONObject(0).get("identifier"));
		String userId = (String) obj.get("id");

		String name = obj.getJSONObject("firstName").getJSONObject("localized").get("en_US") + " "
				+ obj.getJSONObject("lastName").getJSONObject("localized").get("en_US");

		String imgUrl = (String) obj.getJSONObject("profilePicture").getJSONObject("displayImage~")
				.getJSONArray("elements").getJSONObject(0).getJSONArray("identifiers").getJSONObject(0)
				.get("identifier");
		Optional<Provider> profilet = profileRepository.findById(userId);

		User user = null;

		if (profilet.isPresent())
			user = profilet.get().getUser();
		else {
			user = new User(name, name, "", "");

			Provider profile = new Provider();
//			profile.setDescription(name);
			profile.setId(userId);
			profile.setName(name);
			System.out.println(rs.getExpires_in());
			profile.setExpireAt(rs.getExpires_in());
//			profile.setGeoEnabled(twitterProfile.isGeoEnabled());
//			profile.setUrl(twitterProfile.getProfileUrl());
			profile.setImage(imgUrl);
//			profile.setSecure(twitterProfile.isProtected());
			profile.setProviderType(ProviderType.LINKEDIN);
			profile.setToken(rs.getAccess_token());

			Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
					.orElseThrow(() -> new SocialException(Constant.INTERNAL_ERROR));

			user.setRoles(Collections.singleton(userRole));
			user.setImage(imgUrl);
			user.setCreator(ProviderType.LINKEDIN);
			user.addProfile(profile);
		}

		User result = userRepository.save(user);

		return ResponseEntity.ok(new UserData(tokenProvider.toToken(result), UserPrincipal.create(result)));
	}

	@PostMapping("/twitter/request-token")
	public ResponseEntity<UserData> twitterRqToken(@Valid @RequestBody SocialRq socialRq) {

		TwitterConnectionFactory connectionFactory = new TwitterConnectionFactory(socialConfig.getTwitterKey(),
				socialConfig.getTwitterSecret());
		OAuth1Operations oauthOperations = connectionFactory.getOAuthOperations();

//		OAuthToken rqAccessToken = oauthOperations.exchangeForAccessToken(
//				new AuthorizedRequestToken(new OAuthToken(socialRq.getRequestToken(), socialRq.getOauthVerifier()),null ),
//				null);

		// upon receiving the callback from the provider:
		OAuthToken accessToken = oauthOperations.exchangeForAccessToken(new AuthorizedRequestToken(
				new OAuthToken(socialRq.getRequestToken(), null), socialRq.getOauthVerifier()), null);

		System.out.println(accessToken.getSecret());
		System.out.println(accessToken.getValue());

//		OAuthToken accessToken = new OAuthToken(rqAccessToken.getValue(), rqAccessToken.getSecret());
		Connection<Twitter> twitterConnection = connectionFactory.createConnection(accessToken);
		Twitter twitter = twitterConnection.getApi();
//		twitterConnection.updateStatus("hello all my friends");

		UserOperations userOperations = twitter.userOperations();
		TwitterProfile twitterProfile = userOperations.getUserProfile();

		long twitterID = userOperations.getProfileId();

//		twitter.timelineOperations().updateStatus("hello all");

		Optional<Provider> profilet = profileRepository.findById(String.valueOf(twitterID));

		User user = null;

		if (profilet.isPresent()) {
			Provider prof = profilet.get();
			user = prof.getUser();
			prof.setToken(accessToken.getValue());
			prof.setSecret(accessToken.getSecret());

			System.out.println("Token updated");
			profileRepository.save(prof);
		} else {
			user = new User(twitterProfile.getName(), twitterProfile.getName(), "", "");

			Provider profile = new Provider();
			profile.setDescription(twitterProfile.getDescription());
			profile.setId(Long.toString(twitterID));
			profile.setName(twitterProfile.getName());
			profile.setGeoEnabled(twitterProfile.isGeoEnabled());
			profile.setUrl(twitterProfile.getProfileUrl());
			profile.setImage(twitterProfile.getProfileImageUrl());
			profile.setSecure(twitterProfile.isProtected());
			profile.setProviderType(ProviderType.TWITTER);
			profile.setToken(accessToken.getValue());
			profile.setSecret(accessToken.getSecret());

			Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
					.orElseThrow(() -> new SocialException(Constant.INTERNAL_ERROR));

			user.setRoles(Collections.singleton(userRole));
			user.setBio(twitterProfile.getDescription());
			user.setImage(twitterProfile.getProfileImageUrl());
			user.setCreator(ProviderType.TWITTER);
			user.addProfile(profile);
		}

		User result = userRepository.save(user);

		return ResponseEntity.ok(new UserData(tokenProvider.toToken(result), UserPrincipal.create(result)));
	}

	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpRq signUpRequest, BindingResult bindResult) {
		if (userRepository.existsByUsername(signUpRequest.getName())) {
			throw new ResourceAlreadyExistException("Username", signUpRequest.getName());
		}

		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			throw new ResourceAlreadyExistException("Email", signUpRequest.getEmail());
		}

		// Creating user's account
		User user = new User(signUpRequest.getName(), signUpRequest.getName(), signUpRequest.getEmail(),
				signUpRequest.getPassword());
		user.setCreator(ProviderType.SELF);

		user.setPassword(passwordEncoder.encode(user.getPassword()));

		Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
				.orElseThrow(() -> new SocialException(Constant.INTERNAL_ERROR));

		user.setRoles(Collections.singleton(userRole));

		User result = userRepository.save(user);

		URI location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/users/{username}")
				.buildAndExpand(result.getUsername()).toUri();

		return ResponseEntity.ok(new UserData(tokenProvider.toToken(result), UserPrincipal.create(result)));
	}

}
