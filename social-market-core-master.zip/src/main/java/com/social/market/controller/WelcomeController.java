package com.social.market.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WelcomeController {

    // inject via application.properties

    @RequestMapping("/")
    public String home() {
        return "index";
    }

}
