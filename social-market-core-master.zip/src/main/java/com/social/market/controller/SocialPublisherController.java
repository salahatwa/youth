package com.social.market.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.social.market.config.secuirty.CurrentUser;
import com.social.market.config.secuirty.UserPrincipal;
import com.social.market.domain.Provider;
import com.social.market.domain.Task;
import com.social.market.repository.ProviderRepository;
import com.social.market.service.SocialPuplisher;
import com.social.market.service.TaskService;
import com.social.market.service.schedule.ScheduleService;

@RestController
@RequestMapping("/publish")
public class SocialPublisherController {

	@Autowired
	private SocialPuplisher publisher;

	@Autowired
	private TaskService taskService;

	
	@Autowired
	private ScheduleService scheduleService;
	
	@Autowired
	private ProviderRepository providerRepository;
	
	@PostMapping("/post/{id}")
	public void publish(@CurrentUser UserPrincipal currentUser, @PathVariable long id) {

		
		
		Task task = taskService.getEntityTaskForUser(currentUser.getId(), id);

//		task.setDate("2020-09-01");
//		task.setTime("15:50");
		task.setTimezoneOffset(-120);
		task.setEnabled(true);
//		task.setScheduled(true);
		
		System.out.println(task);
		
//		scheduleService.schedulePost(currentUser.getId(), task);
		
		List<Provider> providers = providerRepository.findAllProvidersByTaskId(task.getId());
		
		System.out.println("----------");
		System.out.println(providers);

//		for (Provider provider2 : providers) {
//
//			switch (provider2.getProviderType()) {
//			case LINKEDIN:
////				publisher.publishToLinkedIn(task, provider2);
//				break;
//
//			case TWITTER:
////				publisher.publishToTwitter(task, provider2);
//				break;
//
//			default:
//				break;
//			}
//
//		}

	}

}
